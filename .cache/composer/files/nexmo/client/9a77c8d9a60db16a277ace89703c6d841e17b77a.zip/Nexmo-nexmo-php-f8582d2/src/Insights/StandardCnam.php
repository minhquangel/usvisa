<?php
namespace Nexmo\Insights;

class StandardCnam extends Standard
{
    use CnamTrait;
}